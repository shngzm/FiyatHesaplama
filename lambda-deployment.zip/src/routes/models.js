import express from 'express';
import { authenticateToken, requireAdmin } from '../middleware/auth.js';
import * as modelController from '../controllers/modelController.js';

const router = express.Router();

router.get('/', modelController.getAllModels);
router.get('/:id', modelController.getModelById);
router.post('/', authenticateToken, requireAdmin, modelController.createModel);
router.put('/:id', authenticateToken, requireAdmin, modelController.updateModel);
router.delete('/:id', authenticateToken, requireAdmin, modelController.deleteModel);

export default router;
