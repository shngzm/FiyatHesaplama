// Lambda Handler for Express App
import serverlessHttp from 'serverless-http';
import app from './src/server.js';

// Configure serverless-http with binary types
const serverlessHandler = serverlessHttp(app, {
  binary: ['image/*', 'application/pdf']
});

// Export handler for Lambda with CORS support
export const handler = async (event, context) => {
  // Add CORS headers to the response
  const response = await serverlessHandler(event, context);
  
  // Ensure CORS headers are present
  if (!response.headers) {
    response.headers = {};
  }
  
  response.headers['Access-Control-Allow-Origin'] = event.headers?.origin || 'https://staging.d12wynbw2ij4ni.amplifyapp.com';
  response.headers['Access-Control-Allow-Methods'] = 'GET, POST, PUT, DELETE, OPTIONS';
  response.headers['Access-Control-Allow-Headers'] = 'Content-Type, Authorization';
  response.headers['Access-Control-Allow-Credentials'] = 'true';
  
  return response;
};

